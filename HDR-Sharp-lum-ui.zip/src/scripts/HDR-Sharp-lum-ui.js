#engine v8
#feature-id HDRSharpenSuite : Utilities > HDR & Sharpening Suite
#feature-info An advanced graphical interface to adjust configurations and generate custom dynamic micro-contrast blend profiles.

// ============================================================================
// HDR-Sharp-lum-ui.js — Unified Front-End UI & Core Processing Engine
// ============================================================================

#include <pjsr/DataType.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/NumericControl.jsh>

// ----------------------------------------------------------------------------
// BACKEND ENGINE PROCESSING PIPELINE
// ----------------------------------------------------------------------------
function RunEnginePipeline(wHdr, mmt3, mmt4, usmS, usmA, wSharp, wOrig) {
    var activeWin = ImageWindow.activeWindow;
    if (activeWin.isNull) {
        console.writeln("Error: No active image workspace open.");
        return;
    }

    console.writeln("=== Starting Backend Processing Pipeline ===");
    
    // Extract or Clone Luminance
    var baseLumWin;
    if (activeWin.currentView.image.isColor) {
        var ccie = new ChannelExtraction;
        ccie.colorSpace = ChannelExtraction.prototype.CIELab;
        ccie.channels = [[true, ""], [false, ""], [false, ""]];
        ccie.executeOn(activeWin.mainView);
        baseLumWin = ImageWindow.activeWindow;
        baseLumWin.mainView.id = "Original_Luminance";
    } else {
        baseLumWin = new ImageWindow(
            activeWin.mainView.image.width, activeWin.mainView.image.height,
            activeWin.mainView.image.numberOfChannels, activeWin.bitsPerSample,
            activeWin.isFloatSample, activeWin.mainView.image.isColor, "Original_Luminance"
        );
        baseLumWin.mainView.beginProcess(0); 
        baseLumWin.mainView.image.apply(activeWin.mainView.image);
        baseLumWin.mainView.endProcess();
        baseLumWin.show();
    }
    
    var baseLumId = baseLumWin.mainView.id;
    var processedWins = [];
    var processedObjects = [];

    // Helper function for explicit structural cloning
    function clone(src, id) {
        var cl = new ImageWindow(src.mainView.image.width, src.mainView.image.height, src.mainView.image.numberOfChannels, src.bitsPerSample, src.isFloatSample, src.mainView.image.isColor, id);
        cl.mainView.beginProcess(0); cl.mainView.image.apply(src.mainView.image); cl.mainView.endProcess();
        cl.show(); return cl;
    }

    // Process unrolled HDR levels
    for (var i = 5; i <= 9; i++) {
        console.writeln("\n--- Processing HDR Layer Level: " + i + " ---");
        var winL = clone(baseLumWin, "Lum_HDR_L" + i);
        var hdr = new HDRMultiscaleTransform;
        hdr.numberOfLayers = i;
        hdr.numberOfIterations = 1;
        hdr.scalingFunction = "B3 Spline (5)";
        hdr.executeOn(winL.mainView);
        processedWins.push(winL.mainView.id);
        processedObjects.push(winL);
    }

    var formulaHDR = "((Lum_HDR_L5 * 0.20) + (Lum_HDR_L6 * 0.20) + (Lum_HDR_L7 * 0.20) + (Lum_HDR_L8 * 0.20) + (Lum_HDR_L9 * 0.20)) * " + wHdr.toFixed(4) + " + (" + baseLumId + " * " + (1.0 - wHdr).toFixed(4) + ")";
    console.writeln("\n=== Generating Intermediate HDR Blend ===");
    var pm = new PixelMath; pm.expression = formulaHDR; pm.useSingleExpression = true; pm.createNewImage = true; pm.newImageId = "hdrblend";
    pm.executeOn(ImageWindow.windowById(baseLumId).mainView);
    var hdrBlendWin = ImageWindow.activeWindow;

    console.writeln("\n=== Processing Sharpening Stages ===");
    var mltWin = clone(hdrBlendWin, "Lum_MMT_Sharp");
    var mmt = new MultiscaleMedianTransform;
    mmt.layers = [[true, true, 0.000], [true, true, 0.000], [true, true, mmt3], [true, true, mmt4], [true, true, 0.100], [true, true, 0.100], [true, true, 0.100], [true, false, 0.000]];
    mmt.executeOn(mltWin.mainView);

    var usmWin = clone(hdrBlendWin, "Lum_USM_Sharp");
    var usm = new UnsharpMask; usm.sigma = usmS; usm.amount = usmA; usm.target = UnsharpMask.prototype.Lightness;
    usm.executeOn(usmWin.mainView);

    var formulaSharp = "(Lum_MMT_Sharp * 0.25) + (Lum_USM_Sharp * 0.25) + (" + baseLumId + " * 0.50)";
    console.writeln("\n=== Generating Intermediate Sharp Blend ===");
    var pmS = new PixelMath; pmS.expression = formulaSharp; pmS.useSingleExpression = true; pmS.createNewImage = true; pmS.newImageId = "sharpblend";
    pmS.executeOn(ImageWindow.windowById(baseLumId).mainView);
    var sharpBlendWin = ImageWindow.activeWindow;

    var finalFormula = "(hdrblend * " + wHdr.toFixed(4) + ") + (sharpblend * " + wSharp.toFixed(4) + ") + (" + baseLumId + " * " + wOrig.toFixed(4) + ")";
    console.writeln("\n=== Executing Final Master Combination ===");
    var pmF = new PixelMath; pmF.expression = finalFormula; pmF.useSingleExpression = true; pmF.createNewImage = true; pmF.newImageId = "lumfinal";
    pmF.executeOn(ImageWindow.windowById(baseLumId).mainView);

    console.writeln("\n=== Executing Workspace Clean-up ===");
    for (var j = 0; j < processedObjects.length; j++) { if (!processedObjects[j].isNull) processedObjects[j].forceClose(); }
    if (!mltWin.isNull) mltWin.forceClose();
    if (!usmWin.isNull) usmWin.forceClose();
    if (!hdrBlendWin.isNull) hdrBlendWin.forceClose();
    if (!sharpBlendWin.isNull) sharpBlendWin.forceClose();
    if (!baseLumWin.isNull) baseLumWin.forceClose();

    console.writeln("\n=== Script Completed Successfully ===");
}

// ----------------------------------------------------------------------------
// GRAPHICAL DASHBOARD SHIELD INTERFACE
// ----------------------------------------------------------------------------
function HDRSharpenUIDialog() {
    this.__base__ = Dialog;
    this.__base__();
    
    var self = this;
    this.windowTitle = "HDR & Sharpening Suite Dashboard";

    this.mainSizer = new VerticalSizer();
    this.mainSizer.margin = 12;
    this.mainSizer.spacing = 10;

    this.helpLabel = new Label(this);
    this.helpLabel.margin = 8;
    this.helpLabel.wordWrapping = true;
    this.helpLabel.text = "Adjust configurations below to generate custom dynamic micro-contrast blend profiles.";
    this.mainSizer.add(this.helpLabel);

    // Group 1: HDR Sub-panel
    this.hdrBox = new GroupBox(this);
    this.hdrBox.title = "HDR Multiscale Transform Options";
    this.hdrBox.sizer = new VerticalSizer();
    this.hdrBox.margin = 6;
    this.hdrBox.spacing = 6;

    this.ctrlWHdr = new NumericControl(this);
    this.ctrlWHdr.label.text = "HDR Mix Weight (Global):";
    this.ctrlWHdr.setRange(0.0, 1.0);
    this.ctrlWHdr.setValue(0.35);
    this.ctrlWHdr.precision = 2;
    this.hdrBox.sizer.add(this.ctrlWHdr);
    this.mainSizer.add(this.hdrBox);

    // Group 2: Sharpening Sub-panel
    this.sharpBox = new GroupBox(this);
    this.sharpBox.title = "Advanced Sharpening Details";
    this.sharpBox.sizer = new VerticalSizer();
    this.sharpBox.margin = 6;
    this.sharpBox.spacing = 6;

    this.ctrlMmt3 = new NumericControl(this);
    this.ctrlMmt3.label.text = "MMT Layer 3 Detail Bias:";
    this.ctrlMmt3.setRange(0.0, 0.5);
    this.ctrlMmt3.setValue(0.100);
    this.ctrlMmt3.precision = 3;
    this.sharpBox.sizer.add(this.ctrlMmt3);

    this.ctrlMmt4 = new NumericControl(this);
    this.ctrlMmt4.label.text = "MMT Layer 4 Detail Bias:";
    this.ctrlMmt4.setRange(0.0, 0.5);
    this.ctrlMmt4.setValue(0.200);
    this.ctrlMmt4.precision = 3;
    this.sharpBox.sizer.add(this.ctrlMmt4);

    this.ctrlUsmSigma = new NumericControl(this);
    this.ctrlUsmSigma.label.text = "Unsharp Mask Radius (Sigma):";
    this.ctrlUsmSigma.setRange(1.0, 30.0);
    this.ctrlUsmSigma.setValue(14.0);
    this.ctrlUsmSigma.precision = 1;
    this.sharpBox.sizer.add(this.ctrlUsmSigma);

    this.ctrlUsmAmt = new NumericControl(this);
    this.ctrlUsmAmt.label.text = "Unsharp Mask Amplitude (Amt):";
    this.ctrlUsmAmt.setRange(0.0, 2.0);
    this.ctrlUsmAmt.setValue(0.80);
    this.ctrlUsmAmt.precision = 2;
    this.sharpBox.sizer.add(this.ctrlUsmAmt);
    this.mainSizer.add(this.sharpBox);

    // Group 3: Mastering Blend panel
    this.mixBox = new GroupBox(this);
    this.mixBox.title = "Final Master Blend Percentage Composition";
    this.mixBox.sizer = new VerticalSizer();
    this.mixBox.margin = 6;
    this.mixBox.spacing = 6;

    this.ctrlWSharp = new NumericControl(this);
    this.ctrlWSharp.label.text = "Sharpened Component Mix:";
    this.ctrlWSharp.setRange(0.0, 1.0);
    this.ctrlWSharp.setValue(0.20);
    this.ctrlWSharp.precision = 2;
    this.mixBox.sizer.add(this.ctrlWSharp);

    this.ctrlWOrig = new NumericControl(this);
    this.ctrlWOrig.label.text = "Original Baseline Mix:";
    this.ctrlWOrig.setRange(0.0, 1.0);
    this.ctrlWOrig.setValue(0.35);
    this.ctrlWOrig.precision = 2;
    this.mixBox.sizer.add(this.ctrlWOrig);
    this.mainSizer.add(this.mixBox);

    // Lower Window Command Action Row Buttons using standard native PushButton
    this.btnSizer = new HorizontalSizer();
    this.btnSizer.spacing = 10;

    this.okBtn = new PushButton(this);
    this.okBtn.text = "Execute Process";
    this.okBtn.onClick = function() { self.ok(); };

    this.cancelBtn = new PushButton(this);
    this.cancelBtn.text = "Close Control Panel";
    this.cancelBtn.onClick = function() { self.cancel(); };

    this.btnSizer.addStretch();
    this.btnSizer.add(this.okBtn);
    this.btnSizer.add(this.cancelBtn);

    this.mainSizer.addSpacing(6);
    this.mainSizer.add(this.btnSizer);
    this.sizer = this.mainSizer;
    this.adjustToContents();
}

HDRSharpenUIDialog.prototype = new Dialog();

// ----------------------------------------------------------------------------
// ENTRY INITIALIZATION MAIN
// ----------------------------------------------------------------------------
function main() {
    var win = ImageWindow.activeWindow;
    if (win.isNull) {
