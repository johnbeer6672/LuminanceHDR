#engine v8
#feature-id HDRSharpenSuite : Utilities > HDR & Sharpening Suite
#feature-info An advanced interface to generate custom dynamic micro-contrast blend profiles.

// ============================================================================
// HDR-Sharp-lum-ui.js — Headless Automation Safe Unified Code Block
// ============================================================================

function RunEnginePipeline(wHdr, mmt3, mmt4, usmS, usmA, wSharp, wOrig) {
    var activeWin = ImageWindow.activeWindow;
    if (activeWin.isNull) {
        console.writeln("Error: No active image workspace open.");
        return;
    }

    console.writeln("=== Starting Backend Processing Pipeline ===");
    
    var baseLumWin;
    if (activeWin.currentView.image.isColor) {
        var ccie = new ChannelExtraction;
        ccie.colorSpace = 3; 
        ccie.channels = [[true, ""], [false, ""], [false, ""]];
        ccie.executeOn(activeWin.mainView);
        baseLumWin = ImageWindow.activeWindow;
        baseLumWin.mainView.id = "Original_Luminance";
    } else {
        baseLumWin = new ImageWindow(
            activeWin.mainView.image.width, activeWin.mainView.image.height,
            activeWin.mainView.image.numberOfChannels, activeWin.bitsPerSample,
            activeWin.isFloatSample, activeWin.mainView.image.isColor, "Original_Luminance"
        );
        baseLumWin.mainView.beginProcess(0); 
        baseLumWin.mainView.image.apply(activeWin.mainView.image);
        baseLumWin.mainView.endProcess();
        baseLumWin.show();
    }
    
    var baseLumId = baseLumWin.mainView.id;
    var processedWins = [];
    var processedObjects = [];

    function clone(src, id) {
        var cl = new ImageWindow(src.mainView.image.width, src.mainView.image.height, src.mainView.image.numberOfChannels, src.bitsPerSample, src.isFloatSample, src.mainView.image.isColor, id);
        cl.mainView.beginProcess(0); cl.mainView.image.apply(src.mainView.image); cl.mainView.endProcess();
        cl.show(); return cl;
    }

    for (var i = 5; i <= 9; i++) {
        console.writeln("\n--- Processing HDR Layer Level: " + i + " ---");
        var winL = clone(baseLumWin, "Lum_HDR_L" + i);
        var hdr = new HDRMultiscaleTransform;
        hdr.numberOfLayers = i;
        hdr.numberOfIterations = 1;
        hdr.scalingFunction = "B3 Spline (5)";
        hdr.executeOn(winL.mainView);
        processedWins.push(winL.mainView.id);
        processedObjects.push(winL);
    }

    var formulaHDR = "((Lum_HDR_L5 * 0.20) + (Lum_HDR_L6 * 0.20) + (Lum_HDR_L7 * 0.20) + (Lum_HDR_L8 * 0.20) + (Lum_HDR_L9 * 0.20)) * " + wHdr.toFixed(4) + " + (" + baseLumId + " * " + (1.0 - wHdr).toFixed(4) + ")";
    console.writeln("\n=== Generating Intermediate HDR Blend ===");
    var pm = new PixelMath; pm.expression = formulaHDR; pm.useSingleExpression = true; pm.createNewImage = true; pm.newImageId = "hdrblend";
    pm.executeOn(ImageWindow.windowById(baseLumId).mainView);
    var hdrBlendWin = ImageWindow.activeWindow;

    console.writeln("\n=== Processing Sharpening Stages ===");
    var mltWin = clone(hdrBlendWin, "Lum_MMT_Sharp");
    var mmt = new MultiscaleMedianTransform;
    
    // Explicit 7-parameter array matrix layout configuration signature per row layer
    mmt.layers = [
        [true, true, 0.000, false, 1.000, 1.00, 0.00], // Layer 1
        [true, true, 0.000, false, 1.000, 1.00, 0.00], // Layer 2
        [true, true, mmt3,   false, 1.000, 1.00, 0.00], // Layer 3 (Detail Bias Assigned)
        [true, true, mmt4,   false, 1.000, 1.00, 0.00], // Layer 4 (Detail Bias Assigned)
        [true, true, 0.100, false, 1.000, 1.00, 0.00], // Layer 5
        [true, true, 0.100, false, 1.000, 1.00, 0.00], // Layer 6
        [true, true, 0.100, false, 1.000, 1.00, 0.00], // Layer 7
        [true, false, 0.000, false, 1.000, 1.00, 0.00] // Layer 8 (Residual)
    ];
    mmt.executeOn(mltWin.mainView);

    var usmWin = clone(hdrBlendWin, "Lum_USM_Sharp");
    var usm = new UnsharpMask; usm.sigma = usmS; usm.amount = usmA; usm.target = 3; 
    usm.executeOn(usmWin.mainView);

    var formulaSharp = "(Lum_MMT_Sharp * 0.25) + (Lum_USM_Sharp * 0.25) + (" + baseLumId + " * 0.50)";
    console.writeln("\n=== Generating Intermediate Sharp Blend ===");
    var pmS = new PixelMath; pmS.expression = formulaSharp; pmS.useSingleExpression = true; pmS.createNewImage = true; pmS.newImageId = "sharpblend";
    pmS.executeOn(ImageWindow.windowById(baseLumId).mainView);
    var sharpBlendWin = ImageWindow.activeWindow;

    var finalFormula = "(hdrblend * " + wHdr.toFixed(4) + ") + (sharpblend * " + wSharp.toFixed(4) + ") + (" + baseLumId + " * " + wOrig.toFixed(4) + ")";
    console.writeln("\n=== Executing Final Master Combination ===");
    var pmF = new PixelMath; pmF.expression = finalFormula; pmF.useSingleExpression = true; pmF.createNewImage = true; pmF.newImageId = "lumfinal";
    pmF.executeOn(ImageWindow.windowById(baseLumId).mainView);

    console.writeln("\n=== Executing Workspace Clean-up ===");
    for (var j = 0; j < processedObjects.length; j++) { if (!processedObjects[j].isNull) processedObjects[j].forceClose(); }
    if (!mltWin.isNull) mltWin.forceClose();
    if (!usmWin.isNull) usmWin.forceClose();
    if (!hdrBlendWin.isNull) hdrBlendWin.forceClose();
    if (!sharpBlendWin.isNull) sharpBlendWin.forceClose();
    if (!baseLumWin.isNull) baseLumWin.forceClose();

    console.writeln("\n=== Script Completed Successfully ===");
}

function BuildDashboardDialog(dlg) {
    dlg.windowTitle = "HDR & Sharpening Suite Dashboard";
    
    dlg.mainSizer = new Sizer(true);
    dlg.mainSizer.margin = 12;
    dlg.mainSizer.spacing = 10;

    dlg.helpLabel = new Label(dlg);
    dlg.helpLabel.margin = 8;
    dlg.helpLabel.wordWrapping = true;
    dlg.helpLabel.text = "Adjust configurations below to generate custom dynamic micro-contrast blend profiles.";
    dlg.mainSizer.add(dlg.helpLabel);

    dlg.hdrBox = new GroupBox(dlg);
    dlg.hdrBox.title = "HDR Multiscale Transform Options";
    dlg.hdrBox.sizer = new Sizer(true);
    dlg.hdrBox.margin = 6;
    dlg.hdrBox.spacing = 6;

    dlg.ctrlWHdr = new NumericControl(dlg);
    dlg.ctrlWHdr.label.text = "HDR Mix Weight (Global):";
    dlg.ctrlWHdr.setRange(0.0, 1.0);
    dlg.ctrlWHdr.setValue(0.35);
    dlg.ctrlWHdr.precision = 2;
    dlg.hdrBox.sizer.add(dlg.ctrlWHdr);
    dlg.mainSizer.add(dlg.hdrBox);

    dlg.sharpBox = new GroupBox(dlg);
    dlg.sharpBox.title = "Advanced Sharpening Details";
    dlg.sharpBox.sizer = new Sizer(true);
    dlg.sharpBox.margin = 6;
    dlg.sharpBox.spacing = 6;

    dlg.ctrlMmt3 = new NumericControl(dlg);
    dlg.ctrlMmt3.label.text = "MMT Layer 3 Detail Bias:";
    dlg.ctrlMmt3.setRange(0.0, 0.5);
    dlg.ctrlMmt3.setValue(0.100);
    dlg.ctrlMmt3.precision = 3;
    dlg.sharpBox.sizer.add(dlg.ctrlMmt3);

    dlg.ctrlMmt4 = new NumericControl(dlg);
    dlg.ctrlMmt4.label.text = "MMT Layer 4 Detail Bias:";
    dlg.ctrlMmt4.setRange(0.0, 0.5);
    dlg.ctrlMmt4.setValue(0.200);
    dlg.ctrlMmt4.precision = 3;
    dlg.sharpBox.sizer.add(dlg.ctrlMmt4);

    dlg.ctrlUsmSigma = new NumericControl(dlg);
    dlg.ctrlUsmSigma.label.text = "Unsharp Mask Radius (Sigma):";
    dlg.ctrlUsmSigma.setRange(1.0, 30.0);
    dlg.ctrlUsmSigma.setValue(14.0);
    dlg.ctrlUsmSigma.precision = 1;
    dlg.sharpBox.sizer.add(dlg.ctrlUsmSigma);

    dlg.ctrlUsmAmt = new NumericControl(dlg);
    dlg.ctrlUsmAmt.label.text = "Unsharp Mask Amplitude (Amt):";
    dlg.ctrlUsmAmt.setRange(0.0, 2.0);
    dlg.ctrlUsmAmt.setValue(0.80);
    dlg.ctrlUsmAmt.precision = 2;
    dlg.sharpBox.sizer.add(dlg.ctrlUsmAmt);
    dlg.mainSizer.add(dlg.sharpBox);

    dlg.mixBox = new GroupBox(dlg);
    dlg.mixBox.title = "Final Master Blend Percentage Composition";
    dlg.mixBox.sizer = new Sizer(true);
    dlg.mixBox.margin = 6;
    dlg.mixBox.spacing = 6;

    dlg.ctrlWSharp = new NumericControl(dlg);
    dlg.ctrlWSharp.label.text = "Sharpened Component Mix:";
    dlg.ctrlWSharp.setRange(0.0, 1.0);
    dlg.ctrlWSharp.setValue(0.20);
    dlg.ctrlWSharp.precision = 2;
    dlg.mixBox.sizer.add(dlg.ctrlWSharp);

    dlg.ctrlWOrig = new NumericControl(dlg);
    dlg.ctrlWOrig.label.text = "Original Baseline Mix:";
    dlg.ctrlWOrig.setRange(0.0, 1.0);
    dlg.ctrlWOrig.setValue(0.35);
    dlg.ctrlWOrig.precision = 2;
    dlg.mixBox.sizer.add(dlg.ctrlWOrig);
    dlg.mainSizer.add(dlg.mixBox);

    dlg.btnSizer = new Sizer(false);
    dlg.btnSizer.spacing = 10;

    dlg.okBtn = new PushButton(dlg);
    dlg.okBtn.text = "Execute Process";
    dlg.okBtn.onClick = function() { dlg.ok(); };

    dlg.cancelBtn = new PushButton(dlg);
    dlg.cancelBtn.text = "Close Control Panel";
    dlg.cancelBtn.onClick = function() { dlg.cancel(); };

    dlg.btnSizer.addStretch();
    dlg.btnSizer.add(dlg.okBtn);
    dlg.btnSizer.add(dlg.cancelBtn);

    dlg.mainSizer.addSpacing(6);
    dlg.mainSizer.add(dlg.btnSizer);
    dlg.sizer = dlg.mainSizer;
    dlg.adjustToContents();
}

function main() {
    var activeWin = ImageWindow.activeWindow;
    if (activeWin.isNull) {
        var msg = new MessageBox("Error: No active destination window opened. Open an image first.", "HDRSharpenSuite", 2, 1);
        msg.execute();
        return;
    }
    var dashboard = new Dialog();
    BuildDashboardDialog(dashboard);
    if (dashboard.execute()) {
        console.show();
        RunEnginePipeline(
            dashboard.ctrlWHdr.value,
            dashboard.ctrlMmt3.value,
            dashboard.ctrlMmt4.value,
            dashboard.ctrlUsmSigma.value,
            dashboard.ctrlUsmAmt.value,
            dashboard.ctrlWSharp.value,
            dashboard.ctrlWOrig.value
        );
    }
}

main();
